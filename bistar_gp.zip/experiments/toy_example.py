"""
Toy Example: sin(x) + 0.25x + noise
Reproduces thesis Chapter 5 Figures 10a, 11a, 11b.
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import torch
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from bistar_gp import (
    generate_toy_data, build_toy_kernels, build_model, build_likelihood,
    fit_map, print_hyperparameters, decompose_model,
)
from bistar_gp.viz import plot_decomposition

torch.set_default_dtype(torch.float64)


def main():
    print("=" * 50)
    print("  Toy Example: sin(x) + 0.25x + noise")
    print("=" * 50)

    # 1. Data
    x_train, y_train, info = generate_toy_data(n_points=20, noise_std=0.5, bias_slope=0.25, seed=42)
    print(f"\n{len(x_train)} data points generated")

    # 2. Model
    kernels, names = build_toy_kernels()
    model, likelihood = build_model(x_train, y_train, kernels, names)

    # 3. Fit
    print("\nFitting (MAP)...")
    losses = fit_map(model, likelihood, x_train, y_train, n_iter=500, lr=0.05)
    print_hyperparameters(model, likelihood)

    # 4. Decompose
    x_test = torch.linspace(-11.0, 11.0, 200).double()
    result = decompose_model(model, likelihood, x_train, y_train, x_test, n_samples=25)

    # 5. Plot
    x_np = x_test.numpy()
    true_components = {"unbiased_se": np.sin(x_np), "bias_linear": 0.25 * x_np}

    fig = plot_decomposition(
        result,
        true_components=true_components,
        true_combined=np.sin(x_np) + 0.25 * x_np,
        suptitle="BI* Decomposition: sin(x) + 0.25x",
    )
    fig.savefig("toy_decomposition.png", bbox_inches="tight", dpi=150)
    print("Saved: toy_decomposition.png")

    plt.close("all")
    print("Done!")


if __name__ == "__main__":
    main()
