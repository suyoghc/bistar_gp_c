# bistar_gp

**BI* with Gaussian Process decomposition** — implements the framework from Chandramouli & Shiffrin (2020) for additive kernel composition, bias mitigation, and debiasing.

## Core idea

Observed data = true signal + bias + noise. Represent each with a GP kernel. Fit the sum kernel. Decompose the posterior into individual components (Eq. 5). Extract the unbiased estimate.

## Structure

```
bistar_gp/
├── decompose.py     # Eq. 5 — pure PyTorch, no framework dependency
├── model.py         # GPyTorch wrapper with constraints + robustness
├── fit.py           # MAP (marginal likelihood) + simple MCMC
├── debias.py        # Full pipeline: fit → decompose → debias
├── data.py          # Toy data + Mauna Loa loader
├── viz.py           # Thesis-style figures
experiments/
├── toy_example.py   # sin(x) + 0.25x + noise → reproduces thesis
├── mauna_loa.py     # CO2 → trend + seasonal + medium-term
config/
└── defaults.yaml    # All hyperprior specs and settings
```

## Quick start

```bash
pip install torch gpytorch matplotlib numpy scikit-learn

# Toy example (thesis figures)
python experiments/toy_example.py

# Mauna Loa CO2 decomposition
python experiments/mauna_loa.py
```

## Cholesky stability

Built-in protections:
- Float64 everywhere
- Hyperparameter constraints (away from zero)
- Progressive jitter fallback
- Try/catch in training loop

## Extending

Add new kernel components by:
1. Define kernel in `model.py` (with constraints!)
2. Add to a `build_*_kernels()` function
3. Run the same `decompose_model()` pipeline — it handles any number of additive components

The decomposition math (`decompose.py`) is framework-agnostic. Swap GPyTorch for something else and the core still works.
